
        
        
        <?php $__env->startSection('content'); ?>
        <main class="content">
            <div class="cards">
                <!-- inicia tarjeta dinamica-->
                <?php $__empty_1 = true; $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card card-small">
                    <div class="card-body">
                        <h4><?php echo e($nota->titulo); ?></h4>

                        <p>
                            <?php echo $nota->contenido; ?> <!-- todo sanitizar HTML para evitar ataque XSS-->
                        </p>
                    </div>

                    <footer class="card-footer">
                        <a href="<?php echo e(route('notas.edit', ['id' =>$nota->id])); ?>"  class="action-link action-edit">
                            <i class="icon icon-pen"></i>
                        </a>
                        <a class="action-link action-delete">
                            <i class="icon icon-trash"></i>
                        </a>
                    </footer>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>no hay elementos disponibles </br> <a href="/agregar">Agregar notas</a></p>
                <?php endif; ?>
                <!-- termina tarjeta dinamica -->
            
            </div>
        </main>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ULSA\ProyectoNotas\resources\views/notas.blade.php ENDPATH**/ ?>