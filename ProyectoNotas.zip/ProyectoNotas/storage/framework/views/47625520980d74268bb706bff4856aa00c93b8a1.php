        
        
        
        <?php $__env->startSection('content'); ?>
        <main class="content">
            <div class="cards">
                <div class="card card-center">
                    <div class="card-body">
                        <h1><?php echo e($notas->titulo); ?></h1>

                        <form method="POST" action="<?php echo e(url("notas/{$notas->id}/editar")); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label for="title" class="field-label">Título: </label>
                            <input type="text" name="title" id="title" class="field-input" value="<?php echo e($notas->titulo); ?>">
                            <!-- placeholder="<?php echo e($notas->titulo); ?>"-->
                            <label for="content" class="field-label">Contenido:</label>
                            <textarea name="content" id="content" rows="10" class="field-textarea"><?php echo $notas->contenido; ?></textarea>

                            <button type="submit" class="btn btn-primary">Editar nota</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ULSA\ProyectoNotas\resources\views/editar.blade.php ENDPATH**/ ?>