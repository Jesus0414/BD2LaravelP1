        
        
        
        <?php $__env->startSection('content'); ?>
        <main class="content">
            <div class="cards">
                <div class="card card-center">
                    <div class="card-body">
                        <h1>Nueva nota</h1>

                        <form method="POST" action="<?php echo e(url('crear')); ?>">
                            <?php echo csrf_field(); ?>
                            <label for="title" class="field-label">Título: </label>
                            <input type="text" name="title" id="title" class="field-input" required>

                            <label for="content" class="field-label">Contenido:</label>
                            <textarea name="content" id="content" rows="10" class="field-textarea" required></textarea>

                            <button type="submit" class="btn btn-primary">Crear nota</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ULSA\ProyectoNotas\resources\views/agregar.blade.php ENDPATH**/ ?>